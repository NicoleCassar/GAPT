﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FYPAllocationTest.Models;
using FYPAllocationTest.ViewModels;
using System.Text;
using System.IO;
using Microsoft.Data.SqlClient;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;

namespace FYPAllocationTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly IStudentRepository _studentRepository;

        public HomeController(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        

        public IActionResult Index()
        {
            ViewBag.Title = "Student Data";
            var model = new StudentViewModel();
            model.student = _studentRepository.GetAllData();
            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

       [HttpPost]
       public FileResult Export_Tutors()
        {
            List<String> columnData = new List<String>();
            string connectionstring = "Server=localhost\\MSSQLSERVER2;Database=fypallocation;Trusted_Connection=True;MultipleActiveResultSets=true";
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                connection.Open();
                string query = "SELECT * FROM supervisor";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            columnData.Add(reader[0].ToString()
                                + "," + reader[1].ToString()
                                + "," + reader[2].ToString()
                                + "," + reader[3].ToString()
                                + "," + reader[4].ToString());
                        }
                    }
                }
            }
            var sw = new StreamWriter("Tutors.csv", false, Encoding.UTF8);
            foreach (var item in columnData)
                sw.WriteLine(item);
            sw.Close();
            byte[] fileBytes = System.IO.File.ReadAllBytes(@"Tutors.csv");
            string fileName = "Tutors.csv";
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }

        public FileResult Export_Students()
        {
            List<String>columnData = new List<String>();
            string connectionstring = "Server=localhost\\MSSQLSERVER2;Database=fypallocation;Trusted_Connection=True;MultipleActiveResultSets=true";
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                connection.Open();
                string query = "SELECT * FROM student ORDER BY average_mark DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            columnData.Add(reader[0].ToString()
                                + "," + reader[1].ToString()
                                + "," + reader[2].ToString()
                                + "," + reader[3].ToString()
                                + "," + reader[4].ToString());
                        }
                    }
                }
            }
            var sw = new StreamWriter("students.csv", false, Encoding.UTF8);
            foreach (var item in columnData)
                sw.WriteLine(item);
            sw.Close();
            byte[] fileBytes = System.IO.File.ReadAllBytes(@"students.csv");
            string fileName = "students.csv";
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }

       
        public ActionResult FYPAlloc()
        {
            Export_Tutors();
            Export_Students();
            ScriptEngine engine = Python.CreateEngine();
            engine.ExecuteFile(@"SMPAlgtoCSV.py");
            if (System.IO.File.Exists("SMPResult.csv"))
            {
                StreamReader sr = new StreamReader("SMPResult.csv");
                List<string> res = new List<string>();
                string line;
                // Read and display lines from the file until the end of 
                // the file is reached.
                while ((line = sr.ReadLine()) != null)
                {
                    res.Add(line);
                }
                var result = res.ToList();
                ViewBag.Message = result;
                return View(result);
            }
            else
            {
                List<string> res = new List<string>();
                res.Add("No results available");
                var result = res.ToList();
               // ViewBag.Message = result;
                return View(result);
            }
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
