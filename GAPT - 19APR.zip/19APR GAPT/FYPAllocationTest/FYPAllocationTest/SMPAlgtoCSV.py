import csv #for reading a csv file
i = 0 #to iterate a 2D array for row in reader
k = 0
student = []
audit = open("Allocation_Log.txt", 'w')
#pathfile = open("path.txt", 'r')
#path = pathfile.read()
csv_file = open("students.csv", 'r') #CSV file being read from
csv_test = open("SMPResult.csv", 'w') #CSV file to write the results to.
writer = csv.writer(csv_test, delimiter=",")
reader = csv.reader(csv_file)
for row in reader: #Each element with the csv file is read and saved below:
    student.append([]) # Adding a new 2D element with each iteration.
    name = row[0]
    surname = row[1]
    ID = row[2]
    Email = row[3]
    grade = row[4]
    pref1 = row[5]
    pref2 = row[6]
    pref3 = row[7]
    pref4 = row[8]
    pref5 = row[9]
    pref6 = row[10]
    assigned_to = ""
    choices = []
    student[i].append(name)
    student[i].append(surname)
    student[i].append(ID)
    student[i].append(grade)
    student[i].append([pref1, pref2, pref3, pref4, pref5, pref6]) 
    student[i].append(assigned_to)
    student[i].append(choices)
    i += 1
tutor = []
tutors_file = open("Tutors.csv", 'r') #CSV file being read from
tread = csv.reader(tutors_file)
for row in tread:
    tutor.append([])
    name = row[0] + " " + row[1]
    print(name)
    is_free = True
    tutor[k].append(name)
    tutor[k].append(is_free)
    k += 1




def get_name_of_preferred_tutor(stud): #Retrieve first preference of student.
    for i in range(0, len(student)):
        if student[i][0] == stud:
            return student[i][4][0]

def is_assigned(person): #Check if student has been assigned to a tutor
    for i in range(0, len(student)):
        if student[i][0] == person and student[i][1] == False:
             return True


def tutor_is_assigned(person): #check if tutor has been assigned to a student
    for i in range(0, len(tutor)):
        if tutor[i][0] == person and tutor[i][1] == False:
             return True
    return False

def is_assigned_to(person): #Retrieve the student name to which a given tutor is assigned
    for i in range(0, len(student)):
        if student[i][5] == person:
                return student[i][0]
    return False

def avg1(candidate1): #Retrieve the average mark of the current student the tutor is assigned to
    for x in range(0, len(student)):
        if student[x][0] == candidate1:
            return int(student[x][3])
                

def avg2(candidate2): #Retrieve the average mark of the new student to check if they get their first preference
    for x in range(0, len(student)):
        if student[x][0] == candidate2:
            return int(student[x][3])

def awarded_to(candidate): #Check Tutor Availability
     for x in range(0, len(student)):
         if student[x][0] == candidate: #new student gets their second preference and so on..
            audit.write("\n%s %s: Checking tutor availbility \n" %(student[x][1], (student[x][2])))
            audit.write("%s Preference 1 NOT AVAILABLE \n" %(student[x][4][0]))
            for i in range(1, 5):
                if not tutor_is_assigned(student[x][4][i]):
                    audit.write("%s Preference %s AVAILABLE \n" %(student[x][4][i], i+1))
                    return student[x][4][i]
                else:
                    audit.write("%s Preference %s NOT AVAILABLE \n" %(student[x][4][i], i+1))
                

def assign(stud, tut): #Assigning tutor to student
    for i in range(0, len(student)):
        if student[i][0] == stud:
            audit.write("\n%s %s: Checking tutor availbility \n" %(student[i][1], (student[i][2])))
            student[i][5] = tut
            audit.write("%s Preference 1 AVAILABLE \n" %(student[i][5]))
    for k in range(0, len(tutor)): #Marking the allocated tutor as no longer free
        if tutor[k][0] == tut:
            tutor[k][1] = False

def main():        
    for x in range(0, len(student)):
        stud = student[x][0] #Get student name
        if not is_assigned(stud): #check if student is assigned
            tutorforFYP = get_name_of_preferred_tutor(stud) #if not get first preference tutor.
            if tutor_is_assigned(tutorforFYP): #if their first preference is assigned:
                assignedTutor = awarded_to(stud)#Compare the two
                assign(stud, assignedTutor) #Assign the student with the resultant tutor
            else:
                assign(stud, tutorforFYP)#if the tutor is still available, simply assign.

def end(): #Basic print implementation for test data
    print("Resolution:\n")
    for i in range(0, len(student)):
        stud = student[i][1] + " " + student[i][2]
        tut = student[i][5]

        print(stud + " is assigned to " + tut)
        returntoweb(stud, tut, i)
    

def returntoweb(stud, tut, i):
    writer.writerow([stud + " is assigned to " + tut])
    
        
   


main() #Execute methods main and end
end()
csv_test.close();
audit.close();
    
  



#Read arrays of data from csv file
#Execute Simulated SMP
#Write result to CSV file.

#To-do:
#1. Write resultant student and tutor to csv file
#2. Read the csv result into a php file



